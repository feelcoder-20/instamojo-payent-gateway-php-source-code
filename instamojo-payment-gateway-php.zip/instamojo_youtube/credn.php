<?php
define("API_KEY","your api key");
define("AUTH_TOKEN","your auth token");

?>